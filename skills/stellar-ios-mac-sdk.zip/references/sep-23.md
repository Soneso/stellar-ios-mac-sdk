# SEP-23: Strkey Encoding

**Purpose:** Encode and decode Stellar addresses (public keys, seeds, contract IDs, muxed accounts, etc.) using the strkey format — versioned base32 with CRC-16 checksum.

All examples assume `import stellarsdk`.

**Prerequisites:** None — these are pure utility methods on `String` and `Data`.

**Specification:** [SEP-0023](https://github.com/stellar/stellar-protocol/blob/master/ecosystem/sep-0023.md)

## Table of Contents

1. [Address Types and Prefixes](#address-types-and-prefixes)
2. [Decoding Addresses (String → Data)](#decoding-addresses)
3. [Encoding Addresses (Data → String)](#encoding-addresses)
4. [Validation](#validation)
5. [Muxed Accounts (M-addresses)](#muxed-accounts)
6. [Signed Payloads (P-addresses)](#signed-payloads)
7. [Contract IDs (C-addresses)](#contract-ids)
8. [Muxed Contracts (W-addresses)](#muxed-contracts)
9. [Liquidity Pool IDs (L-addresses)](#liquidity-pool-ids)
10. [Claimable Balance IDs (B-addresses)](#claimable-balance-ids)
11. [Error Handling](#error-handling)
12. [Common Pitfalls](#common-pitfalls)

---

## Address Types and Prefixes

The SDK's internal `VersionByte` enum defines the version byte for each address type. It is not public API: code uses the public `String` and `Data` helpers, which apply the right version byte. The table lists the bytes for reference:

| Type | Prefix | `VersionByte` case | Raw value | Use |
|------|--------|-------------------|-----------|-----|
| Ed25519 public key | `G` | `.ed25519PublicKey` | 48 | Standard account address |
| Ed25519 secret seed | `S` | `.ed25519SecretSeed` | 144 | Private key (never share) |
| Muxed Ed25519 public key | `M` | `.med25519PublicKey` | 96 | Account with embedded memo ID |
| Pre-authorized TX hash | `T` | `.preAuthTX` | 152 | Multi-sig signer |
| SHA-256 hash | `X` | `.sha256Hash` | 184 | Hash-based signer |
| Signed payload | `P` | `.signedPayload` | 120 | CAP-40 payload signer |
| Smart contract | `C` | `.contract` | 16 | Soroban contract address |
| Muxed contract | `W` | `.muxedContract` | 176 | Contract with embedded multiplexing ID |
| Liquidity pool | `L` | `.liquidityPool` | 88 | AMM pool identifier |
| Claimable balance | `B` | `.claimableBalance` | 8 | Claimable balance identifier |

All standard address types (G, S, T, X, C, L) encode to **56 characters**. Muxed accounts (M) and muxed contracts (W) are **69 characters**. Claimable balances (B) are **58 characters**. Signed payloads (P) are **69 to 165 characters**.

---

## Decoding Addresses

`String` extensions decode strkey strings back to raw `Data`. All decode methods throw `KeyUtilsError` on failure, and `decodeMuxedAccount()` reports a malformed 56-character account ID as `Ed25519Error.invalidPublicKey` instead.

```swift
import stellarsdk
import Foundation

// G-address → 32-byte raw public key
let pubKeyData: Data = try "GBPXXOA5N4JYPESHAADMQKBPWZWQDQ64ZV6ZL2S3LAGW4SY7NTCMWIVL".decodeEd25519PublicKey()

// S-address → 32-byte raw seed
let seedData: Data = try "SBGWKM3CD4IL47QN6X54N6Y33T3JDNVI6AIJ6CD5IM47HG3IG4O36XCU".decodeEd25519SecretSeed()

// T-address → 32-byte raw pre-auth TX hash
let preAuthData: Data = try "TA3D5KRYM6CB7OWQ6TWYRR3Z4T7GNZLKERYNZGGA5SOAOPIFY6YQGZAM".decodePreAuthTx()

// X-address → 32-byte raw SHA-256 hash
let hashData: Data = try "XA3D5KRYM6CB7OWQ6TWYRR3Z4T7GNZLKERYNZGGA5SOAOPIFY6YQH5FV".decodeSha256Hash()

// C-address → 32-byte raw contract ID
let contractData: Data = try "CA3D5KRYM6CB7OWQ6TWYRR3Z4T7GNZLKERYNZGGA5SOAOPIFY6YQGAXE".decodeContractId()

// C-address → hex string
let contractHex: String = try "CA3D5KRYM6CB7OWQ6TWYRR3Z4T7GNZLKERYNZGGA5SOAOPIFY6YQGAXE".decodeContractIdToHex()
// → "363eaa3867841fbad0f4ed88c779e4fe66e56a2470dc98c0ec9c073d05c7b103"

// L-address → 32-byte raw liquidity pool ID
let lpData: Data = try "LA7QYNF7SOWQ3GLR2BGMZEHXAVIRZA4KVWLTJJFC7MGXUA74P7UJUPJN".decodeLiquidityPoolId()

// L-address → hex string
let lpHex: String = try "LA7QYNF7SOWQ3GLR2BGMZEHXAVIRZA4KVWLTJJFC7MGXUA74P7UJUPJN".decodeLiquidityPoolIdToHex()

// B-address → raw data (33 bytes: 1-byte type discriminant + 32-byte ID)
let cbData: Data = try "BAAD6DBUX6J22DMZOHIEZTEQ64CVCHEDRKWZONFEUL5Q26QD7R76RGR4TU".decodeClaimableBalanceId()

// B-address → hex string (includes 1-byte type discriminant "00" prefix)
let cbHex: String = try "BAAD6DBUX6J22DMZOHIEZTEQ64CVCHEDRKWZONFEUL5Q26QD7R76RGR4TU".decodeClaimableBalanceIdToHex()
// → "003f0c34bf93ad0d9971d04ccc90f705511c838aad9734a4a2fb0d7a03fc7fe89a"

// M-address → MuxedAccountXDR
let muxed: MuxedAccountXDR = try "MA7QYNF7SOWQ3GLR2BGMZEHXAVIRZA4KVWLTJJFC7MGXUA74P7UJVAAAAAAAAAAAAAJLK".decodeMuxedAccount()

// M-address → raw data (for raw XDR bytes)
let muxedData: Data = try "MA7QYNF7SOWQ3GLR2BGMZEHXAVIRZA4KVWLTJJFC7MGXUA74P7UJVAAAAAAAAAAAAAJLK".decodeMed25519PublicKey()

// W-address → raw data (40 bytes: 32-byte contract ID + 8-byte big-endian multiplexing ID)
let muxedContractData: Data = try "WA3D5KRYM6CB7OWQ6TWYRR3Z4T7GNZLKERYNZGGA5SOAOPIFY6YQGAAAAAAAAAPCIA6IG".decodeMuxedContractId()

// P-address → Ed25519SignedPayload
let signedPayload: Ed25519SignedPayload = try "PA7QYNF7SOWQ3GLR2BGMZEHXAVIRZA4KVWLTJJFC7MGXUA74P7UJUAAAAAQACAQDAQCQMBYIBEFAWDANBYHRAEISCMKBKFQXDAMRUGY4DUPB6IBZGM".decodeSignedPayload()
let pk: PublicKey = try signedPayload.publicKey()           // the signer's public key
let payloadBytes: Data = signedPayload.payload              // the raw payload
```

---

## Encoding Addresses

`Data` extensions encode raw bytes into strkey strings. All encode methods throw on failure.

```swift
import stellarsdk

// pubKeyData, seedData, preAuthData, hashData, contractData, lpData, cbData, muxedData
// and muxedContractData are the values the decode calls above bind; xdrEncodedMuxedData
// is the XDR encoding of a MuxedAccountXDR

// 32-byte raw data → G-address
let gAddress: String = try pubKeyData.encodeEd25519PublicKey()

// 32-byte raw data → S-address
let sAddress: String = try seedData.encodeEd25519SecretSeed()

// 32-byte raw data → T-address
let tAddress: String = try preAuthData.encodePreAuthTx()

// 32-byte raw data → X-address
let xAddress: String = try hashData.encodeSha256Hash()

// 32-byte raw data → C-address
let cAddress: String = try contractData.encodeContractId()

// 32-byte raw data → L-address
let lAddress: String = try lpData.encodeLiquidityPoolId()

// 32-byte raw data → B-address
// NOTE: encodeClaimableBalanceId() auto-prepends the 1-byte type discriminant
// if data is exactly 32 bytes. Pass 33-byte data (with discriminant) or 32-byte
// data (without discriminant) — both work.
let bAddress: String = try cbData.encodeClaimableBalanceId()

// MuxedAccountXDR bytes → M- or G-address
// Decodes as MuxedAccountXDR first; returns M-address for med25519, G-address for ed25519
let muxedAddress: String = try xdrEncodedMuxedData.encodeMuxedAccount()

// XDR-encoded MuxedAccountXDR → M-address only (med25519 raw data)
let mAddress: String = try muxedData.encodeMEd25519AccountId()

// 40-byte raw data → W-address
let wAddress: String = try muxedContractData.encodeMuxedContractId()
```

### Encode from hex strings

`String` extensions let you encode directly from hex without manually constructing `Data`:

```swift
// Hex → C-address
let cAddress: String = try "363eaa3867841fbad0f4ed88c779e4fe66e56a2470dc98c0ec9c073d05c7b103".encodeContractIdHex()
// → "CA3D5KRYM6CB7OWQ6TWYRR3Z4T7GNZLKERYNZGGA5SOAOPIFY6YQGAXE"

// Hex → L-address
let lAddress: String = try "3f0c34bf93ad0d9971d04ccc90f705511c838aad9734a4a2fb0d7a03fc7fe89a".encodeLiquidityPoolIdHex()
// → "LA7QYNF7SOWQ3GLR2BGMZEHXAVIRZA4KVWLTJJFC7MGXUA74P7UJUPJN"

// Hex (WITHOUT 1-byte discriminant) → B-address (discriminant is added automatically)
let bAddress: String = try "3f0c34bf93ad0d9971d04ccc90f705511c838aad9734a4a2fb0d7a03fc7fe89a".encodeClaimableBalanceIdHex()
// → "BAAD6DBUX6J22DMZOHIEZTEQ64CVCHEDRKWZONFEUL5Q26QD7R76RGR4TU"
```

### Encode signed payload (P-address)

```swift
import stellarsdk
import Foundation

// Build from public key + payload bytes
let pk = try PublicKey(accountId: "GA7QYNF7SOWQ3GLR2BGMZEHXAVIRZA4KVWLTJJFC7MGXUA74P7UJVSGZ")
let payload = Data([0x01, 0x02, 0x03, 0x04])  // 1–64 bytes
let signedPayload = Ed25519SignedPayload(ed25519: pk.wrappedData32(), payload: payload)
let pAddress: String = try signedPayload.encodeSignedPayload()

// Round-trip verification
let decoded = try pAddress.decodeSignedPayload()
let recoveredKey: PublicKey = try decoded.publicKey()
let recoveredPayload: Data = decoded.payload
```

---

## Validation

Validation methods return `Bool` and never throw. Use them to check user input before attempting a decode.

`isValid*` returns false for exactly the inputs its matching `decode*` throws on. Both apply the same rules:

| Rule | What must hold |
|------|----------------|
| Encoded length | Exactly 56 characters for G, S, T, X, C, L; 69 for M and W; 58 for B; 69 to 165 for P. A length outside the range is rejected before anything is decoded |
| Base32 | Only A–Z and 2–7, no `=` padding, and the string must be the canonical encoding of the bytes it decodes to |
| Version byte | The leading decoded byte must be the one the requested type uses |
| Checksum | The trailing CRC-16 must match the version byte plus the body |
| Signed payload framing (P) | Body is the 32-byte signer key, a 4-byte big-endian length field naming **1 to 64** bytes, the signed data, and zero padding to a multiple of four. Body width must be exactly `36 + paddedWidth(declaredLength)`, and every padding byte must be `0x00` |
| Claimable balance discriminant (B) | Body must open with `CLAIMABLE_BALANCE_ID_TYPE_V0` (`0x00`), the only type the XDR union defines |

```swift
// Ed25519 public key (G-address, 56 chars)
"GBPXXOA5N4JYPESHAADMQKBPWZWQDQ64ZV6ZL2S3LAGW4SY7NTCMWIVL".isValidEd25519PublicKey()  // true
"SBGWKM3CD4IL47QN6X54N6Y33T3JDNVI6AIJ6CD5IM47HG3IG4O36XCU".isValidEd25519PublicKey()  // false (S-address)

// Secret seed (S-address, 56 chars)
"SBGWKM3CD4IL47QN6X54N6Y33T3JDNVI6AIJ6CD5IM47HG3IG4O36XCU".isValidEd25519SecretSeed()  // true
"GBPXXOA5N4JYPESHAADMQKBPWZWQDQ64ZV6ZL2S3LAGW4SY7NTCMWIVL".isValidEd25519SecretSeed()  // false (G-address)

// Muxed account (M-address, 69 chars)
"MA7QYNF7SOWQ3GLR2BGMZEHXAVIRZA4KVWLTJJFC7MGXUA74P7UJVAAAAAAAAAAAAAJLK".isValidMed25519PublicKey()  // true

// Muxed contract (W-address, 69 chars)
"WA3D5KRYM6CB7OWQ6TWYRR3Z4T7GNZLKERYNZGGA5SOAOPIFY6YQGAAAAAAAAAPCIA6IG".isValidMuxedContractId()  // true
"CA3D5KRYM6CB7OWQ6TWYRR3Z4T7GNZLKERYNZGGA5SOAOPIFY6YQGAXE".isValidMuxedContractId()  // false (C-address)

// Pre-auth TX hash (T-address, 56 chars)
"TA3D5KRYM6CB7OWQ6TWYRR3Z4T7GNZLKERYNZGGA5SOAOPIFY6YQGZAM".isValidPreAuthTx()  // true

// SHA-256 hash (X-address, 56 chars)
"XA3D5KRYM6CB7OWQ6TWYRR3Z4T7GNZLKERYNZGGA5SOAOPIFY6YQH5FV".isValidSha256Hash()  // true

// Signed payload (P-address, 69 to 165 chars)
"PA7QYNF7SOWQ3GLR2BGMZEHXAVIRZA4KVWLTJJFC7MGXUA74P7UJUAAAAAQACAQDAQCQMBYIBEFAWDANBYHRAEISCMKBKFQXDAMRUGY4DUPB6IBZGM".isValidSignedPayload()  // true

// Contract ID (C-address, 56 chars)
"CA3D5KRYM6CB7OWQ6TWYRR3Z4T7GNZLKERYNZGGA5SOAOPIFY6YQGAXE".isValidContractId()  // true
"GA3D5KRYM6CB7OWQ6TWYRR3Z4T7GNZLKERYNZGGA5SOAOPIFY6YQGAXE".isValidContractId()  // false (wrong prefix)

// Liquidity pool ID (L-address, 56 chars)
"LA7QYNF7SOWQ3GLR2BGMZEHXAVIRZA4KVWLTJJFC7MGXUA74P7UJUPJN".isValidLiquidityPoolId()  // true

// Claimable balance ID (B-address, 58 chars)
"BAAD6DBUX6J22DMZOHIEZTEQ64CVCHEDRKWZONFEUL5Q26QD7R76RGR4TU".isValidClaimableBalanceId()  // true

// Hex string utility
"3f0c34bf93ad0d9971d04ccc90f705511c838aad9734a4a2fb0d7a03fc7fe89a".isHexString()  // true
"not-hex".isHexString()  // false
"123".isHexString()  // false (odd length)
```

### Validate before decode pattern

```swift
func processAddress(_ address: String) throws -> Data {
    // WRONG: call decode directly on untrusted input — throws on any invalid string
    // let data = try address.decodeEd25519PublicKey()

    // CORRECT: validate first, then decode
    guard address.isValidEd25519PublicKey() else {
        throw MyError.invalidAddress("Expected a G-address, got: \(address)")
    }
    return try address.decodeEd25519PublicKey()
}
```

---

## Muxed Accounts

Muxed accounts (M-addresses) embed a 64-bit ID inside a standard G-address to allow virtual sub-accounts without on-chain records.

```swift
import stellarsdk
import Foundation

// Decode M-address → MuxedAccountXDR
let address = "MA7QYNF7SOWQ3GLR2BGMZEHXAVIRZA4KVWLTJJFC7MGXUA74P7UJVAAAAAAAAAAAAAJLK"
let muxed: MuxedAccountXDR = try address.decodeMuxedAccount()

// Access base G-address and mux ID
let baseAccountId: String = muxed.ed25519AccountId  // the underlying G-address
let muxId: UInt64? = muxed.id                       // nil for plain ed25519, UInt64 for med25519

// Decode a G-address also works — returns .ed25519 case with id == nil
let gMuxed: MuxedAccountXDR = try "GBJRYVWMCM4IYZDEB7AUB7Q4IY64HLLWD5A3ZLONHDEDZ66YSU4IXS5N".decodeMuxedAccount()
// gMuxed.id == nil

// Build a MuxedAccountXDR and re-encode to M-address
let pk = try PublicKey(accountId: "GBJRYVWMCM4IYZDEB7AUB7Q4IY64HLLWD5A3ZLONHDEDZ66YSU4IXS5N")
let muxedStruct = MuxedAccountMed25519XDR(id: 12345, sourceAccountEd25519: pk.bytes)
let muxXdr = MuxedAccountXDR.med25519(muxedStruct)
var encoded = try XDREncoder.encode(muxXdr)
let muxData = Data(bytes: &encoded, count: encoded.count)
let mAddress: String = try muxData.encodeMuxedAccount()   // M-address

// Validate M-address
mAddress.isValidMed25519PublicKey()  // true

// Round-trip: M-address → raw bytes → M-address
let rawMuxedData = "3f0c34bf93ad0d9971d04ccc90f705511c838aad9734a4a2fb0d7a03fc7fe89a8000000000000000".data(using: .hexadecimal)!
let roundTripped: String = try rawMuxedData.encodeMEd25519AccountId()
```

---

## Signed Payloads

Signed payloads (P-addresses, CAP-40) combine an Ed25519 public key with an arbitrary payload (1–64 bytes).

```swift
import stellarsdk
import Foundation

// Build a signed payload signer using Signer utility
let accountId = "GA7QYNF7SOWQ3GLR2BGMZEHXAVIRZA4KVWLTJJFC7MGXUA74P7UJVSGZ"
let payload = Data([0x01, 0x02, 0x03, 0x04])   // 1–64 bytes

// Creates a SignerKeyXDR for use in SetOptions
let signerKey: SignerKeyXDR = try Signer.signedPayload(accountId: accountId, payload: payload)

// Build P-address from Ed25519SignedPayload directly
let pk = try PublicKey(accountId: accountId)
let signedPayload = Ed25519SignedPayload(ed25519: pk.wrappedData32(), payload: payload)
let pAddress: String = try signedPayload.encodeSignedPayload()
// → "PA7QYNF7SOWQ3..."

// Validate and decode
enum MyError: Error { case invalidSignedPayload }   // your app's error type
guard pAddress.isValidSignedPayload() else { throw MyError.invalidSignedPayload }
let decoded: Ed25519SignedPayload = try pAddress.decodeSignedPayload()
let signerPublicKey: PublicKey = try decoded.publicKey()
let payloadData: Data = decoded.payload

// Payload size constraints
// WRONG: payload larger than 64 bytes throws StellarSDKError.invalidArgument
let tooLarge = Data(repeating: 0, count: 65)
do {
    _ = try Signer.signedPayload(accountId: accountId, payload: tooLarge)
} catch {
    print("Rejected: \(error)")  // invalid payload length 65, must be 1 to 64 bytes
}

// WRONG: an empty payload has no P-address, so encoding throws StellarSDKError.invalidArgument
let emptyPayload = Ed25519SignedPayload(ed25519: pk.wrappedData32(), payload: Data())
do {
    _ = try emptyPayload.encodeSignedPayload()
} catch {
    print("Rejected: \(error)")
}
```

---

## Contract IDs

```swift
import stellarsdk
import Foundation

let contractStrKey = "CA3D5KRYM6CB7OWQ6TWYRR3Z4T7GNZLKERYNZGGA5SOAOPIFY6YQGAXE"

// Validate
contractStrKey.isValidContractId()  // true

// Decode C-address → raw Data (32 bytes)
let contractData: Data = try contractStrKey.decodeContractId()

// Decode C-address → hex string
let contractHex: String = try contractStrKey.decodeContractIdToHex()
// → "363eaa3867841fbad0f4ed88c779e4fe66e56a2470dc98c0ec9c073d05c7b103"

// Encode raw Data → C-address
let cAddress: String = try contractData.encodeContractId()

// Encode hex string → C-address
let cFromHex: String = try "363eaa3867841fbad0f4ed88c779e4fe66e56a2470dc98c0ec9c073d05c7b103".encodeContractIdHex()

// Use with SCAddressXDR (for Soroban contract invocations)
let address = try SCAddressXDR(contractId: contractStrKey)   // accepts C-address or hex
```

---

## Muxed Contracts

Muxed contract addresses (W-addresses, CAP-84) pair a contract ID with a 64-bit multiplexing ID. They are valid for `MuxedAddress` contract parameters and never as Soroban authorization addresses.

```swift
import stellarsdk
import Foundation

// Build from a C-address and an ID
let muxed = try MuxedContract(contractId: "CA3D5KRYM6CB7OWQ6TWYRR3Z4T7GNZLKERYNZGGA5SOAOPIFY6YQGAXE", id: 123456)
let wAddress: String = muxed.address
// → "WA3D5KRYM6CB7OWQ6TWYRR3Z4T7GNZLKERYNZGGA5SOAOPIFY6YQGAAAAAAAAAPCIA6IG"

// Parse a W-address: contractId is the underlying C-address, id the multiplexing ID
let parsed = try MuxedContract(address: wAddress)
let baseContractId: String = parsed.contractId   // "CA3D5KRYM6CB7OWQ6TWYRR3Z4T7GNZLKERYNZGGA5SOAOPIFY6YQGAXE"
let muxId: UInt64? = parsed.id                   // 123456

// A C-address parses too: id is nil and address is the C-address
let plain = try MuxedContract(address: baseContractId)
// plain.id == nil

// Convert to and from SCAddressXDR (the .muxedContract arm)
let scAddress: SCAddressXDR = parsed.toSCAddress()
let fromScAddress = try MuxedContract(scAddress: scAddress)
let fromStrKey = try SCAddressXDR(muxedContractId: wAddress)
let fromParts = try SCAddressXDR(contractId: baseContractId, id: 123456)

// MuxedContractXDR round trip
let muxedXdr = try MuxedContractXDR(muxedContractId: wAddress)
let reEncoded: String = try muxedXdr.toStrKey()   // same W-address
```

---

## Liquidity Pool IDs

```swift
import stellarsdk
import Foundation

let lpStrKey = "LA7QYNF7SOWQ3GLR2BGMZEHXAVIRZA4KVWLTJJFC7MGXUA74P7UJUPJN"

// Validate
lpStrKey.isValidLiquidityPoolId()  // true

// Decode L-address → raw Data (32 bytes)
let lpData: Data = try lpStrKey.decodeLiquidityPoolId()

// Decode L-address → hex string
let lpHex: String = try lpStrKey.decodeLiquidityPoolIdToHex()
// → "3f0c34bf93ad0d9971d04ccc90f705511c838aad9734a4a2fb0d7a03fc7fe89a"

// Encode raw Data → L-address
let lAddress: String = try lpData.encodeLiquidityPoolId()

// Encode hex string → L-address
let lFromHex: String = try "3f0c34bf93ad0d9971d04ccc90f705511c838aad9734a4a2fb0d7a03fc7fe89a".encodeLiquidityPoolIdHex()
```

---

## Claimable Balance IDs

Claimable balance B-addresses include a 1-byte type discriminant (always `0x00` for `claimableBalanceIDTypeV0`) prepended before the 32-byte ID.

```swift
import stellarsdk
import Foundation

let cbStrKey = "BAAD6DBUX6J22DMZOHIEZTEQ64CVCHEDRKWZONFEUL5Q26QD7R76RGR4TU"

// Validate
cbStrKey.isValidClaimableBalanceId()  // true

// Decode B-address → raw Data (33 bytes: 1-byte discriminant + 32-byte ID)
let cbData: Data = try cbStrKey.decodeClaimableBalanceId()

// Decode B-address → hex string (33 bytes, includes discriminant "00" prefix)
let cbHex: String = try cbStrKey.decodeClaimableBalanceIdToHex()
// → "003f0c34bf93ad0d9971d04ccc90f705511c838aad9734a4a2fb0d7a03fc7fe89a"

// Encode 33-byte Data (with discriminant) → B-address
let bAddress: String = try cbData.encodeClaimableBalanceId()

// Encode 32-byte Data (without discriminant) → B-address (discriminant auto-prepended)
let rawIdData: Data = cbData.dropFirst()  // remove the discriminant byte
let bFromRaw: String = try rawIdData.encodeClaimableBalanceId()  // same result

// Encode hex (32-byte, WITHOUT discriminant) → B-address (discriminant auto-prepended)
let bFromHex: String = try "3f0c34bf93ad0d9971d04ccc90f705511c838aad9734a4a2fb0d7a03fc7fe89a".encodeClaimableBalanceIdHex()

// Encode hex (33-byte, WITH discriminant) → B-address
let bFromFullHex: String = try "003f0c34bf93ad0d9971d04ccc90f705511c838aad9734a4a2fb0d7a03fc7fe89a".data(using: .hexadecimal)!.encodeClaimableBalanceId()

// Use with ClaimableBalanceIDXDR (accepts B-address or hex)
let cbXdr = try ClaimableBalanceIDXDR(claimableBalanceId: cbStrKey)   // from B-address
let cbXdrHex = try ClaimableBalanceIDXDR(claimableBalanceId: cbHex)   // from hex with discriminant

// Render hex from the wrapper: claimableBalanceIdString is the 33-byte body,
// paddedBalanceIdHex the 36-byte XDR encoding Horizon serves (both lower case)
let bodyHex: String = cbXdr.claimableBalanceIdString
// → "003f0c34bf93ad0d9971d04ccc90f705511c838aad9734a4a2fb0d7a03fc7fe89a"
let horizonHex: String = cbXdr.paddedBalanceIdHex
// → "000000003f0c34bf93ad0d9971d04ccc90f705511c838aad9734a4a2fb0d7a03fc7fe89a"

// Use with SCAddressXDR
let address = try SCAddressXDR(claimableBalanceId: cbStrKey)
let strKey = try address.getClaimableBalanceIdStrKey()  // → Optional("BAAD6DBUX6...")
```

---

## Error Handling

All decode methods throw `KeyUtilsError`, and `decodeMuxedAccount()` throws `Ed25519Error.invalidPublicKey` as well. No malformed input escapes as a partially decoded value, and none of them trap — a short or truncated string throws like any other malformed string.

```swift
import stellarsdk

do {
    let data = try "GBPXX0A5N4JYPESHAADMQKBPWZWQDQ64ZV6ZL2S3LAGW4SY7NTCMWIVL".decodeEd25519PublicKey()
} catch KeyUtilsError.invalidEncodedString {
    // Encoded length outside the range the version byte allows, base32 decode failed,
    // re-encoding doesn't match, or the decoded body is malformed (P framing, B discriminant)
    print("Malformed strkey string")
} catch KeyUtilsError.invalidVersionByte {
    // Version byte doesn't match expected type (e.g. S-address passed to decodeEd25519PublicKey)
    print("Wrong address type")
} catch KeyUtilsError.invalidChecksum {
    // CRC-16 checksum doesn't match (transcription error)
    print("Checksum mismatch — address may have a typo")
} catch {
    print("Unexpected error: \(error)")
}
```

`decodeMuxedAccount()` takes either address form and picks its error by input length: a malformed 56-character account ID throws `Ed25519Error.invalidPublicKey`, because that branch runs `PublicKey(accountId:)`, a malformed 69-character muxed address throws `KeyUtilsError`, and an input of any other length throws `KeyUtilsError.invalidEncodedString`. Catch both types.

```swift
import stellarsdk

let address = "GCZHXL5HXQX5ABDM26LHYRCQZ5OJFHLOPLZX47WEBP3V2PF5AVFK2A5E" // last character changed

do {
    let _: MuxedAccountXDR = try address.decodeMuxedAccount()
} catch let error as Ed25519Error {
    print("Malformed account ID: \(error)")      // 56 characters
} catch let error as KeyUtilsError {
    print("Malformed muxed address: \(error)")   // 69 characters
} catch {
    print("Unexpected error: \(error)")
}
```

### Encode-side errors

The encoders reject the payloads that would produce a strkey no decoder reads back, and throw `StellarSDKError.invalidArgument`:

| Method | Requirement |
|--------|-------------|
| `encodeEd25519PublicKey`, `encodeEd25519SecretSeed`, `encodePreAuthTx`, `encodeSha256Hash`, `encodeContractId`, `encodeLiquidityPoolId` | Exactly 32 bytes |
| `encodeMEd25519AccountId`, `encodeMuxedContractId` | Exactly 40 bytes |
| `encodeClaimableBalanceId` | 32 bytes (discriminant prepended), 33 bytes opening with `0x00`, or the 36-byte XDR form Horizon reports (verified, discriminant stripped) |
| `encodeSignedPayload` | A body carrying the signed payload framing, signed data 1–64 bytes |
| `Signer.signedPayload(accountId:payload:)` | Payload 1–64 bytes |
| `encodeContractIdHex`, `encodeLiquidityPoolIdHex`, `encodeClaimableBalanceIdHex` | A valid hex string of the width above |

```swift
import stellarsdk
import Foundation

// Wrong width — there is no G-address for a 31-byte key
do {
    let _ = try Data(repeating: 0, count: 31).encodeEd25519PublicKey()
} catch StellarSDKError.invalidArgument(message: let message) {
    print("Cannot encode: \(message)")
} catch {
    print("Unexpected error: \(error)")
}

// Hex encode errors
do {
    let _ = try "not-hex".encodeContractIdHex()
} catch StellarSDKError.invalidArgument(message: let message) {
    print("Invalid hex: \(message)")
} catch {
    print("Unexpected error: \(error)")
}
```

### Key and seed import

`PublicKey(accountId:)`, `Seed(secret:)`, `KeyPair(accountId:)`, `KeyPair(secretSeed:)`, `MuxedAccount(accountId:)` and `SCAddressXDR(accountId:)` all run the strkey decoder, so they accept exactly the strkeys `decode*` accepts — version byte and CRC-16 checksum included. A secret seed with one wrong character fails its checksum and is rejected.

```swift
import stellarsdk

do {
    // Last character changed: the checksum no longer matches the body
    let _ = try KeyPair(secretSeed: "SBGWKM3CD4IL47QN6X54N6Y33T3JDNVI6AIJ6CD5IM47HG3IG4O36XCV")
} catch Ed25519Error.invalidSeed {
    print("Corrupted secret seed — do not fall back to a derived key, ask the user to re-enter it")
} catch {
    print("Unexpected error: \(error)")
}
```

`KeyPair(accountId:)` reports a malformed account ID the same way, as `Ed25519Error.invalidPublicKey` — see `troubleshooting.md` for the full error contract.

---

## Common Pitfalls

**Wrong decode method for address type:**
```swift
let sAddress = "SBGWKM3CD4IL47QN6X54N6Y33T3JDNVI6AIJ6CD5IM47HG3IG4O36XCU"

// WRONG: throws KeyUtilsError.invalidVersionByte
let data = try sAddress.decodeEd25519PublicKey()

// CORRECT: match the method to the address prefix
let data = try sAddress.decodeEd25519SecretSeed()
```

**Claimable balance hex carries the discriminant, encoding accepts it with or without:**
```swift
// cbStrKey is the B-address bound in "Claimable Balance IDs" above
// decodeClaimableBalanceIdToHex() returns 33-byte hex (WITH 00 prefix)
let cbHex = try cbStrKey.decodeClaimableBalanceIdToHex()
// → "003f0c34bf93ad0d9971d04ccc90f705511c838aad9734a4a2fb0d7a03fc7fe89a"

// The 33-byte form, the 32-byte id and Horizon's 36-byte XDR form (72 hex chars) encode
// to the same B-address: the discriminant is prepended or stripped as needed
let fromBody = try cbHex.encodeClaimableBalanceIdHex()
let fromId = try String(cbHex.dropFirst(2)).encodeClaimableBalanceIdHex()          // same B-address
let fromHorizon = try ("000000" + cbHex).encodeClaimableBalanceIdHex()             // same B-address

// WRONG: any other discriminant, and any length that is neither 32, 33 nor 36 bytes, throws
// StellarSDKError.invalidArgument, since CLAIMABLE_BALANCE_ID_TYPE_V0 is the only type
let wrong = try ("01" + String(cbHex.dropFirst(2))).encodeClaimableBalanceIdHex()  // throws
```

**`isHexString()` returns true for empty string:**
```swift
// Empty string produces valid (but empty) hex data — isHexString() returns true
"".isHexString()  // true (implementation behavior — empty data is valid)

// CORRECT: also check length for non-trivial hex
let hex = ""
guard !hex.isEmpty && hex.isHexString() else { throw MyError.invalidHex }
```

**Odd-length hex strings are invalid:**
```swift
"123".isHexString()      // false — odd length cannot represent bytes
"1234".isHexString()     // true — 2 bytes
"0x1234".isHexString()   // true — 0x prefix is stripped automatically
```

**`encodeMuxedAccount()` vs `encodeMEd25519AccountId()`:**
```swift
// encodeMuxedAccount() decodes the bytes as MuxedAccountXDR first,
// then returns G-address for .ed25519, M-address for .med25519
let result = try xdrData.encodeMuxedAccount()  // M- or G-address depending on content

// encodeMEd25519AccountId() always encodes raw bytes as M-address (med25519 version byte)
// Use only for raw XDR payload bytes of a MuxedAccountMed25519XDR
let mAddress = try rawPayloadBytes.encodeMEd25519AccountId()  // always M-address
```

**Validation checks length AND base32 AND prefix AND checksum AND body shape:**
```swift
// isValidEd25519PublicKey() returns false if:
// - String length != 56 characters
// - Base32 decode fails, or the string is not the canonical encoding of its bytes
// - Version byte != ed25519PublicKey (0x30)
// - CRC-16 checksum doesn't match

// Do NOT assume isValid*() only checks the prefix
let checksumedWrong = "GBPXXOA5N4JYPESHAADMQKBPWZWQDQ64ZV6ZL2S3LAGW4SY7NTCMWIVT"  // last char changed
checksumedWrong.isValidEd25519PublicKey()  // false — checksum mismatch

// isValidSignedPayload() and isValidClaimableBalanceId() additionally check the body:
// - P: length field outside 1–64, body width != 36 + padded data width, or non-zero padding
// - B: body not opening with the CLAIMABLE_BALANCE_ID_TYPE_V0 discriminant (0x00)
// Each of these also makes the matching decode* throw KeyUtilsError.invalidEncodedString
```

**Do not hand-roll strkey validation from the prefix or the length alone:**
```swift
// WRONG: a G prefix and 56 characters say nothing about the checksum, so a
// transcription error slips through as a valid-looking address for another account
if address.hasPrefix("G") && address.count == 56 { /* accept */ }

// CORRECT: let the SDK apply every rule
enum MyError: Error { case invalidAddress(String) }   // your app's error type
guard address.isValidEd25519PublicKey() else { throw MyError.invalidAddress(address) }
```
