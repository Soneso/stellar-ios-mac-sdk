# Soroban Smart Contracts

- [Contract Lifecycle](#contract-lifecycle)
- [High-Level API: SorobanClient](#high-level-api-sorobanclient)
- [Contract Introspection](#contract-introspection)
- [Low-Level API: InvokeHostFunctionOperation](#low-level-api-invokehostfunctionoperation)
- [AssembledTransaction for Mid-Level Control](#assembledtransaction-for-mid-level-control)
- [Multi-Party Authorization](#multi-party-authorization)
- [Error Handling](#error-handling)

All examples assume `import stellarsdk`.

## Contract Lifecycle

Four operations manage Soroban contracts: install WASM, introspect spec, deploy instance, invoke methods. The SDK provides both a low-level `InvokeHostFunctionOperation` API and a high-level `SorobanClient` API.

**IMPORTANT:** `InstallRequest` and `DeployRequest` require `enableServerLogging: Bool` with NO default -- you must pass it explicitly (typically `false`). `ClientOptions` defaults to `false`.

## High-Level API: SorobanClient

`SorobanClient` handles the full lifecycle -- install, deploy, invoke -- with automatic simulation, signing, and submission.

### Install Contract WASM

Upload compiled WASM bytecode. Returns a hex-encoded hash identifying the code on-chain.

```swift
import stellarsdk
import Foundation

let sourceKeyPair = try KeyPair(secretSeed: secretSeed) // secretSeed: your funded account's secret seed ("S...")
let rpcUrl = "https://soroban-testnet.stellar.org"
let wasmData = try Data(contentsOf: URL(fileURLWithPath: "/path/to/contract.wasm"))

let installRequest = InstallRequest(
    rpcUrl: rpcUrl,
    network: Network.testnet,
    sourceAccountKeyPair: sourceKeyPair,
    wasmBytes: wasmData,
    enableServerLogging: false
)

let wasmHash = try await SorobanClient.install(installRequest: installRequest)
print("Installed WASM hash: \(wasmHash)")
```

If the code is already installed, `install` detects this during simulation and returns the existing hash without submitting a transaction. Pass `force: true` to always submit.

---

## Contract Introspection

Parse a contract's spec to discover its functions, types, and events programmatically.

### Loading Contract Info

```swift
import stellarsdk
import Foundation

// wasmHash: the wasm hash returned by the install step
// From local WASM bytecode (offline)
let wasmData = try Data(contentsOf: URL(fileURLWithPath: "/path/to/contract.wasm"))
let contractInfo = try SorobanContractParser.parseContractByteCode(byteCode: wasmData)

// From network (by WASM hash)
let server = SorobanServer(endpoint: "https://soroban-testnet.stellar.org")
let infoEnum = await server.getContractInfoForWasmId(wasmId: wasmHash)
// GetContractInfoEnum cases: .success(response:), .parsingFailure(error:), .rpcFailure(error:)
guard case .success(let info) = infoEnum else {
    throw StellarSDKError.invalidArgument(message: "Could not load contract information for the WASM hash")
}

// From network (by deployed contract ID)
let infoEnum2 = await server.getContractInfoForContractId(contractId: "CB3FU6M3TOAGRBLN5WDLXL6A7VR5SSRGULMXQQOABNMPS25YRJ4CN5VV")
guard case .success(let info2) = infoEnum2 else {
    throw StellarSDKError.invalidArgument(message: "Could not load contract information for the contract ID")
}
```

The `...ForContractId` loaders resolve a CAP-85 external reference executable (Protocol 28)
automatically: the instance names an owner contract and a tag, and the owner's persistent tag
entry holds the wasm hash. `getExternalRefWasmHash(ref: ContractExecutableExternalRefXDR) async
-> GetExternalRefWasmHashResponseEnum` resolves a reference directly: `.success(response: Data)`
carries the 32-byte hash, `.failure` names the condition that fired (non-contract owner, missing
tag entry, entry not contract data, value not a 32-byte hash). A Stellar Asset Contract has no
wasm, so the code loader fails with a message saying so. An executable tag is an XDR string
carrying arbitrary bytes: `ContractExecutableExternalRefXDR.tag` is `Data` (a `tagString` view
reads it as UTF-8 when it spells text), the ledger key is built from the exact bytes, and a
failure message renders a binary tag as `\xNN` escapes inside quotes.

### SorobanContractInfo Properties

| Property | Type | Description |
|----------|------|-------------|
| `envProtocolVersion` | `UInt32` | Environment protocol version |
| `envPreReleaseVersion` | `UInt32` | Environment pre-release version |
| `specEntries` | `[SCSpecEntryXDR]` | All spec entries (raw) |
| `funcs` | `[SCSpecFunctionV0XDR]` | Contract functions |
| `udtStructs` | `[SCSpecUDTStructV0XDR]` | Struct definitions |
| `udtUnions` | `[SCSpecUDTUnionV0XDR]` | Union definitions |
| `udtEnums` | `[SCSpecUDTEnumV0XDR]` | Enum definitions |
| `udtErrorEnums` | `[SCSpecUDTErrorEnumV0XDR]` | Error enum definitions |
| `events` | `[SCSpecEventV0XDR]` | Event definitions |
| `metaEntries` | `[String: String]` | Contract metadata (e.g., `"rsver"`, `"rssdkver"`) |
| `supportedSeps` | `[String]` | SEP numbers from the `"sep"` meta key |

### Listing Functions and Parameters

```swift
for fn in contractInfo.funcs {
    let params = fn.inputs.map { "\($0.name): \(describeType($0.type))" }.joined(separator: ", ")
    let ret = fn.outputs.isEmpty ? "Void" : fn.outputs.map { describeType($0) }.joined(separator: ", ")
    print("fn \(fn.name)(\(params)) -> \(ret)")
}

// Helper to describe a type — use this for printing spec types
func describeType(_ ty: SCSpecTypeDefXDR) -> String {
    // WRONG: case .scSpecTypeU32, .scSpecTypeBool -- no scSpecType prefix exists
    // CORRECT: case .u32, .bool, .address, .string -- short names only
    switch ty {
    case .val: return "Val"
    case .bool: return "Bool"
    case .void: return "Void"
    case .error: return "Error"
    case .u32: return "U32"
    case .i32: return "I32"
    case .u64: return "U64"
    case .i64: return "I64"
    case .timepoint: return "Timepoint"
    case .duration: return "Duration"
    case .u128: return "U128"
    case .i128: return "I128"
    case .u256: return "U256"
    case .i256: return "I256"
    case .bytes: return "Bytes"
    case .string: return "String"
    case .symbol: return "Symbol"
    case .address: return "Address"
    case .muxedAddress: return "MuxedAddress"
    case .option(let o): return "Option<\(describeType(o.valueType))>"
    case .result(let r): return "Result<\(describeType(r.okType)), \(describeType(r.errorType))>"
    case .vec(let v): return "Vec<\(describeType(v.elementType))>"
    case .map(let m): return "Map<\(describeType(m.keyType)), \(describeType(m.valueType))>"
    case .tuple(let t): return "Tuple<\(t.valueTypes.map { describeType($0) }.joined(separator: ", "))>"
    case .bytesN(let b): return "BytesN<\(b.n)>"
    case .udt(let u): return u.name
    }
}
```

### Listing Struct Types

```swift
for s in contractInfo.udtStructs {
    print("Struct: \(s.name)")
    for field in s.fields {
        print("  \(field.name): \(describeType(field.type))")
    }
}
```

### Listing Union Types

```swift
// WRONG: unionCase.name -- SCSpecUDTUnionCaseV0XDR (enum) has no .name
// CORRECT: switch on the case to access the wrapped struct's name
for u in contractInfo.udtUnions {
    print("Union: \(u.name)")
    for c in u.cases {
        switch c {
        case .voidV0(let v): print("  case \(v.name)")
        case .tupleV0(let t): print("  case \(t.name)(\(t.type.map { describeType($0) }.joined(separator: ", ")))")
        }
    }
}
```

### Listing Enum and Error Enum Types

```swift
for e in contractInfo.udtEnums {
    print("Enum: \(e.name)")
    for c in e.cases { print("  \(c.name) = \(c.value)") }
}
for e in contractInfo.udtErrorEnums {
    print("ErrorEnum: \(e.name)")
    for c in e.cases { print("  \(c.name) = \(c.value)") }
}
```

### Listing Events

```swift
// WRONG: event.topics, event.body -- SCSpecEventV0XDR has NO topics/body
// CORRECT: use event.params (array of SCSpecEventParamV0XDR)
for event in contractInfo.events {
    print("Event: \(event.name)")
    for p in event.params {
        print("  \(p.name): \(describeType(p.type))")
    }
}
```

### SCSpecTypeDefXDR Case to SCValXDR Factory Mapping

**Always use the type from introspection** -- do not override based on naming conventions:

```swift
// WRONG: guessing types based on convention — crashes if spec disagrees
// SCValXDR.symbol("MyToken")  // WRONG if spec says String (not Symbol)
// CORRECT: check spec first — spec says String → use SCValXDR.string("MyToken")
```

| SCSpecTypeDefXDR | SCValXDR Factory |
|-----------------|-----------------|
| `.bool` | `SCValXDR.bool(true)` |
| `.void` | `SCValXDR.void` |
| `.u32` | `SCValXDR.u32(UInt32)` |
| `.i32` | `SCValXDR.i32(Int32)` |
| `.u64` | `SCValXDR.u64(UInt64)` |
| `.i64` | `SCValXDR.i64(Int64)` |
| `.u128` | `SCValXDR.u128(UInt128PartsXDR(hi: UInt64, lo: UInt64))` |
| `.i128` | `SCValXDR.i128(Int128PartsXDR(hi: Int64, lo: UInt64))` |
| `.u256` | `SCValXDR.u256(UInt256PartsXDR(...))` |
| `.i256` | `SCValXDR.i256(Int256PartsXDR(...))` |
| `.bytes` | `SCValXDR.bytes(Data)` |
| `.string` | `SCValXDR.string("value")` |
| `.symbol` | `SCValXDR.symbol("name")` |
| `.address` | `SCValXDR.address(try SCAddressXDR(accountId: "G..."))` |
| `.vec(...)` | `SCValXDR.vec([SCValXDR])` |
| `.map(...)` | `SCValXDR.map([SCMapEntryXDR])` |

### ContractSpec Type Conversion

`ContractSpec` auto-converts native Swift values to `SCValXDR` using spec type info:

```swift
// contractInfo: loaded via getContractInfoForContractId (see above)
let spec = ContractSpec(entries: contractInfo.specEntries)

// Convert full function call args (ordered by parameter declaration)
let args = try spec.funcArgsToXdrSCValues(name: "transfer", args: [
    "from": "GA7QYNF7SOWQ3GLR2BGMZEHXAVIRZA4KVWLTJJFC7MGXUA74P7UJVSGZ",  // address → SCValXDR.address (automatic)
    "to": "GCZHXL5HXQX5ABDM26LHYRCQZ5OJFHLOPLZX47WEBP3V2PF5AVFK2A5D",    // address → SCValXDR.address (automatic)
    "amount": 1000,     // i128 → SCValXDR.i128 (automatic)
])

// Single value conversion
let val = try spec.nativeToXdrSCVal(val: 42, ty: .u32)  // SCValXDR.u32(42)
```

**Native Swift → SCValXDR mapping for `funcArgsToXdrSCValues` / `nativeToXdrSCVal`:**

| Spec type | Swift input | Notes |
|-----------|-------------|-------|
| `.address` | `String` (G... or C...) | Auto-converts to SCAddressXDR |
| `.u32`/`.i32`/`.u64`/`.i64` | `Int` | Negative Int throws for unsigned |
| `.u128`/`.i128`/`.u256`/`.i256` | `Int`, `String`, or `Data` | Use `String` for values > Int.max |
| `.string` | `String` | |
| `.symbol` | `String` | |
| `.bool` | `Bool` | |
| `.bytes` / `.bytesN` | `String` (UTF-8) or `Data` | |
| `.vec(...)` | `[Any]` | Element type from spec |
| `.map(...)` | `[AnyHashable: Any]` | Key/value types from spec |
| `.udt(name)` | dict (struct), `Int` (enum), `NativeUnionVal` (union) | See below |
| Any `SCValXDR` | `SCValXDR` | Returned as-is (passthrough) |

**NativeUnionVal — passing union arguments:**

```swift
// Void union case (tag only)
let noneVal = NativeUnionVal(tag: "none")

// Tuple union case (tag + values matching the tuple case types)
let someVal = NativeUnionVal(tag: "some", values: ["hello", 42])

let unionType = SCSpecTypeDefXDR.udt(SCSpecTypeUDTXDR(name: "MyUnion"))
let xdr = try spec.nativeToXdrSCVal(val: someVal, ty: unionType)
```

### Converting Results to Native Swift Values

Two methods turn a returned contract value into native Swift values:

```swift
public func toNative() -> Any?          // SCValXDR: the whole value tree, never throws
public func toStrKey() throws -> String // SCAddressXDR: the "G"/"M"/"C"/"B"/"L" strkey
```

`toNative()` is opt-in -- `SorobanClient`, `AssembledTransaction` and the response types keep returning `SCValXDR`. It never throws: a value with no native counterpart comes back as the `SCValXDR` itself, which `is SCValXDR` detects.

| SCValXDR arm | Native result |
|---|---|
| `.bool` | `Bool` |
| `.void` | `nil` |
| `.u32` / `.i32` / `.u64` / `.i64` | `UInt32` / `Int32` / `UInt64` / `Int64` |
| `.timepoint` / `.duration` | `UInt64` |
| `.u128` / `.i128` / `.u256` / `.i256` | decimal `String` |
| `.bytes` | `Data` |
| `.string` / `.symbol` | `String` |
| `.address` | strkey `String` via `SCAddressXDR.toStrKey()` |
| `.vec` | `[Any?]`, element order preserved; a nil array gives `[]` |
| `.map` | `[AnyHashable: Any?]`, or the `SCValXDR` itself; a nil array gives `[:]` |
| `.error`, `.contractInstance`, `.ledgerKeyContractInstance`, `.ledgerKeyNonce`, `.executableTag` | the `SCValXDR` itself |

An address whose bytes have no strkey encoding also comes back as the `SCValXDR` itself.

**Map key rules.** A map converts as a whole or not at all, and falls back to the `SCValXDR` itself when either

1. a key has no `Hashable` counterpart -- a `.void`, `.vec` or `.map` key, a key of one of the five arms above, or an address key with no strkey; or
2. two keys turn out equal as `AnyHashable`.

Keys otherwise take the value conversion: `.symbol`/`.string` become `String`, the fixed width integers keep their width, `.u128`/`.i128`/`.u256`/`.i256` become decimal `String`, `.bytes` stays `Data`, `.address` becomes its strkey.

`AnyHashable` reads the fixed width integers as one number, which decides what collides:

| Two keys | Outcome |
|---|---|
| `.u32(5)` and `.u64(5)` | equal -- collision, whole map falls back |
| 128 or 256 bit key `5` and `.symbol("5")` | equal (the wide key is the string `"5"`) -- collision |
| `.symbol("5")` and `.u32(5)` | distinct -- both entries survive |
| `.bytes(Data([0x35]))` and `.symbol("5")` | distinct -- both entries survive |
| `.bool(true)` and `.u32(1)` | distinct (`Bool` is outside the numeric reading) |

A dictionary carries no order, so the entry order of a `.map` is not preserved. A lookup by `Int` finds a `.u32` key of the same value, for the same `AnyHashable` reason.

```swift
import stellarsdk

// Scalars keep their exact width, and the wide integers come as decimal strings.
let nonce = SCValXDR.u64(18446744073709551615).toNative()
print(nonce as? UInt64 ?? 0)  // 18446744073709551615

let supply = try SCValXDR.u128(stringValue: "340282366920938463463374607431768211455").toNative()
print(supply as? String ?? "")  // 340282366920938463463374607431768211455

// An address comes as its strkey.
let owner = SCValXDR.address(try SCAddressXDR(accountId: "GBBM6BKZPEHWYO3E3YKREDPQXMS4VK35YLNU7NFBRI26RAN7GI5POFBB")).toNative()
print(owner as? String ?? "")  // GBBM6BKZPEHWYO3E3YKREDPQXMS4VK35YLNU7NFBRI26RAN7GI5POFBB

let contract = try SCAddressXDR(contractId: "CDLZFC3SYJYDZT7K67VZ75HPJVIEUVNIXF47ZG2FB2RMQQVU2HHGCYSC").toStrKey()
print(contract)  // CDLZFC3SYJYDZT7K67VZ75HPJVIEUVNIXF47ZG2FB2RMQQVU2HHGCYSC
```

```swift
import stellarsdk

// A symbol-keyed map becomes a dictionary; look entries up by their key.
let record = SCValXDR.map([
    SCMapEntryXDR(key: SCValXDR.symbol("name"), val: SCValXDR.string("Alice")),
    SCMapEntryXDR(key: SCValXDR.symbol("age"), val: SCValXDR.u32(30)),
])
if let fields = record.toNative() as? [AnyHashable: Any?] {
    print(fields.count)                     // 2
    print(fields["name"] as? String ?? "")  // Alice
    print(fields["age"] as? UInt32 ?? 0)    // 30
}

// A vec keeps its element order, and a nested vec converts with it.
let items = SCValXDR.vec([.u32(1), .symbol("a"), .vec([.bool(true)])]).toNative()
if let elements = items as? [Any?] {
    print(elements[0] as? UInt32 ?? 0)               // 1
    print(elements[1] as? String ?? "")              // a
    print((elements[2] as? [Any?])?[0] as? Bool ?? false)  // true
}
```

**Detecting a map fallback** -- a nil cast tells you nothing about why:

```swift
// WRONG: an unconverted map reads as a nil cast, and the entries are lost
// let fields = value.toNative() as? [AnyHashable: Any?]  // nil, with no way to go on
```

```swift
import stellarsdk

// CORRECT: check for the SCValXDR itself and read the entries per arm
let value = SCValXDR.map([
    SCMapEntryXDR(key: SCValXDR.vec([SCValXDR.u32(1)]), val: SCValXDR.u32(2)),
])
let native = value.toNative()
if let fields = native as? [AnyHashable: Any?] {
    print(fields.count)
} else if let unconverted = native as? SCValXDR {
    for entry in unconverted.map ?? [] {
        print(entry.val.u32 ?? 0)  // 2
    }
}
```

**A u32 key and a u64 key of the same value do not coexist:**

```swift
// WRONG: expecting two entries -- the keys are equal as AnyHashable, so the map falls back
// let fields = mixed.toNative() as? [AnyHashable: Any?]
// print(fields?.count ?? 0)  // 0, not 2: the cast is nil
```

```swift
import stellarsdk

// CORRECT: a map keyed on one integer width converts; a lookup by Int finds the key too
let mixed = SCValXDR.map([
    SCMapEntryXDR(key: SCValXDR.u32(5), val: SCValXDR.symbol("u32")),
    SCMapEntryXDR(key: SCValXDR.u64(5), val: SCValXDR.symbol("u64")),
])
print(mixed.toNative() is SCValXDR)  // true: the two keys collided

let single = SCValXDR.map([
    SCMapEntryXDR(key: SCValXDR.u32(5), val: SCValXDR.symbol("u32")),
])
if let fields = single.toNative() as? [AnyHashable: Any?] {
    print(fields[UInt32(5)] as? String ?? "")  // u32
    print(fields[Int(5)] as? String ?? "")     // u32
}
```

**A 128-bit value is a decimal String, not a number:**

```swift
// WRONG: the conversion produces no integer for a 128 or 256 bit value
// let amount = balance.toNative() as? Int   // nil
// let parts = balance.toNative() as? Int128PartsXDR  // nil
```

```swift
import stellarsdk

// CORRECT: cast to String, and parse it yourself if you need arithmetic
let balance = try SCValXDR.i128(stringValue: "-170141183460469231731687303715884105728")
print(balance.toNative() as? String ?? "")  // -170141183460469231731687303715884105728
```

**Dictionary iteration order is not the map's entry order:**

```swift
// WRONG: assuming the dictionary hands entries back in the order the map carried them
// for (key, value) in fields { ... }  // arbitrary order
```

```swift
import stellarsdk

// CORRECT: take the order from the SCValXDR entries, or look keys up by name
let ordered = SCValXDR.map([
    SCMapEntryXDR(key: SCValXDR.symbol("first"), val: SCValXDR.u32(1)),
    SCMapEntryXDR(key: SCValXDR.symbol("second"), val: SCValXDR.u32(2)),
    SCMapEntryXDR(key: SCValXDR.symbol("third"), val: SCValXDR.u32(3)),
])
for entry in ordered.map ?? [] {
    print(entry.key.symbol ?? "")  // first, second, third
}
```

---

### Deploy Contract Instance

Create a contract instance from an installed WASM hash. Constructor arguments are supported (protocol 22+).

```swift
import stellarsdk

let sourceKeyPair = try KeyPair(secretSeed: secretSeed) // secretSeed: your funded account's secret seed ("S...")
let rpcUrl = "https://soroban-testnet.stellar.org"
let wasmHash = "abc123..."  // from install step

// Constructor arguments (if contract has __constructor)
let adminAddress = try SCAddressXDR(accountId: sourceKeyPair.accountId)
let constructorArgs: [SCValXDR] = [
    SCValXDR.address(adminAddress),
    SCValXDR.u32(1000)
]

let deployRequest = DeployRequest(
    rpcUrl: rpcUrl,
    network: Network.testnet,
    sourceAccountKeyPair: sourceKeyPair,
    wasmHash: wasmHash,
    constructorArgs: constructorArgs,
    enableServerLogging: false
)

let client = try await SorobanClient.deploy(deployRequest: deployRequest)
print("Contract deployed at: \(client.contractId)")
print("Available methods: \(client.methodNames)")
```

### Deploy with Spec-Based Constructor Arguments

**Preferred: use `funcArgsToXdrSCValues` when you have the contract spec.** It auto-converts native Swift values to the correct `SCValXDR` types based on the spec — no manual type mapping needed:

```swift
import stellarsdk

let sourceKeyPair = try KeyPair(secretSeed: secretSeed) // secretSeed: your funded account's secret seed ("S...")
let rpcUrl = "https://soroban-testnet.stellar.org"
let wasmHash = "abc123..."  // from install step

// Load spec from installed WASM
let server = SorobanServer(endpoint: rpcUrl)
let infoEnum = await server.getContractInfoForWasmId(wasmId: wasmHash)
guard case .success(let info) = infoEnum else { throw StellarSDKError.invalidArgument(message: "spec not found") }
let spec = ContractSpec(entries: info.specEntries)

// Auto-convert named args based on __constructor spec types
let constructorArgs = try spec.funcArgsToXdrSCValues(name: "__constructor", args: [
    "admin": sourceKeyPair.accountId,  // String → Address (automatic)
    "decimal": 7,                       // Int → U32 (automatic)
    "name": "MyToken",                  // String → String (automatic)
    "symbol": "MTK",                    // String → Symbol (automatic)
])

let deployRequest = DeployRequest(
    rpcUrl: rpcUrl,
    network: Network.testnet,
    sourceAccountKeyPair: sourceKeyPair,
    wasmHash: wasmHash,
    constructorArgs: constructorArgs,
    enableServerLogging: false
)

let client = try await SorobanClient.deploy(deployRequest: deployRequest)
print("Contract deployed at: \(client.contractId)")
```

```swift
// WRONG: guessing types based on convention — crashes with conversionFailed if spec disagrees
// SCValXDR.symbol("MyToken")  // WRONG if spec says String (not Symbol)

// CORRECT: check spec first — spec says String → use funcArgsToXdrSCValues (auto-converts)
//          or manually use SCValXDR.string("MyToken") if you know the spec type
```

After deployment, you can also get the spec from the client:

```swift
// client: a SorobanClient for the deployed contract (see above)
// sourceKeyPair: your funded account's KeyPair
let spec = client.getContractSpec()
let args = try spec.funcArgsToXdrSCValues(name: "transfer", args: [
    "from": sourceKeyPair.accountId,
    "to": "GCZHXL5HXQX5ABDM26LHYRCQZ5OJFHLOPLZX47WEBP3V2PF5AVFK2A5D",
    "amount": 1000,
])
```

### Deploy from an External Reference (Protocol 28)

A CAP-85 external reference names an owner contract and a tag; the owner's persistent
entry under that tag holds the wasm hash the new instance runs. There is no install
step. `SorobanClient.deployFromExternalRef` resolves the reference before the
transaction is built (an unresolvable reference throws `SorobanClientError.deployFailed`
naming the owner and the tag), loads the spec from the resolved wasm, and returns a
ready client:

```swift
import stellarsdk

let sourceKeyPair = try KeyPair(secretSeed: secretSeed) // secretSeed: your funded account's secret seed ("S...")

let client = try await SorobanClient.deployFromExternalRef(
    deployRequest: DeployFromExternalRefRequest(
        rpcUrl: "https://soroban-testnet.stellar.org",
        network: Network.testnet,
        sourceAccountKeyPair: sourceKeyPair,
        executableOwner: "CB3FU6M3TOAGRBLN5WDLXL6A7VR5SSRGULMXQQOABNMPS25YRJ4CN5VV", // "C..." strkey or the 64 character hex of the id
        tag: "token-v1", // matched byte for byte
        enableServerLogging: false
    )
)
// constructorArgs and salt work as in DeployRequest
```

`deployFromExternalRef` builds the `CREATE_CONTRACT_V2` host function form (empty
constructor-argument vector when no args are given), as `deploy` does.
`DeployFromExternalRefRequest.tag` is `Data` (an executable tag carries arbitrary
bytes); the `String` initializer encodes a text tag as UTF-8 exactly once, and the same
bytes resolve the owner's entry and build the create operation.

The returned client's spec is a snapshot of the wasm the tag named at deployment time.
Re-pointing the tag later changes the code the instance runs, not this client's spec;
build a fresh client with `SorobanClient.forClientOptions` to pick up the new spec.

The underlying create operations can be built directly with
`InvokeHostFunctionOperation.forCreatingContractFromExternalRef(executableOwner:
SCAddressXDR, tag: Data, address: SCAddressXDR, salt: WrappedData32? = nil,
sourceAccountId: String? = nil)` and
`forCreatingContractFromExternalRefWithConstructor(... constructorArguments: [SCValXDR]
...)`, next to their wasm siblings; each has a `tag: String` overload encoding the text
as UTF-8 once. Both builders throw
`StellarSDKError.invalidArgument` for an `executableOwner` that is not a contract
address.

`ContractIdUtils.deriveContractId(deployer: SCAddressXDR, salt: Data, network: Network)
throws -> String` returns the contract id ("C...") a deployment creates. The id derives
from deployer, salt and network only (the executable does not enter it), so the address
is known before deploying. The salt is 32 raw bytes, not hex.

### Invoke Contract Methods

`invokeMethod` automatically distinguishes read-only vs write calls. Read-only calls return simulation results without signing or submitting.

```swift
import stellarsdk

let sourceKeyPair = try KeyPair(secretSeed: secretSeed) // secretSeed: your funded account's secret seed ("S...")
let rpcUrl = "https://soroban-testnet.stellar.org"
let contractId = "CB3FU6M3TOAGRBLN5WDLXL6A7VR5SSRGULMXQQOABNMPS25YRJ4CN5VV" // example contract id — use your deployed contract's id

let clientOptions = ClientOptions(
    sourceAccountKeyPair: sourceKeyPair,
    contractId: contractId,
    network: Network.testnet,
    rpcUrl: rpcUrl
)
let client = try await SorobanClient.forClientOptions(options: clientOptions)

// Read-only call (no signing, returns simulation result)
let balance = try await client.invokeMethod(
    name: "balance",
    args: [SCValXDR.address(try SCAddressXDR(accountId: sourceKeyPair.accountId))]
)
if let balanceValue = balance.i128String {
    print("Balance: \(balanceValue)")
}

// Write call (auto-signed and submitted)
let toAddress = try SCAddressXDR(accountId: "GCZHXL5HXQX5ABDM26LHYRCQZ5OJFHLOPLZX47WEBP3V2PF5AVFK2A5D") // the recipient's account id
let amount = SCValXDR.i128(Int128PartsXDR(hi: 0, lo: 5_000_000_0))
let transferResult = try await client.invokeMethod(
    name: "transfer",
    args: [
        SCValXDR.address(try SCAddressXDR(accountId: sourceKeyPair.accountId)),
        SCValXDR.address(toAddress),
        amount
    ]
)
print("Transfer result: \(transferResult)")
```

### MethodOptions for Fine-Tuning

```swift
import stellarsdk

// client: a SorobanClient for the deployed contract (see above)
// transferArgs: the SCValXDR argument list built as shown above
let methodOptions = MethodOptions(
    fee: 10000,             // 10000 stroops
    timeoutInSeconds: 60,   // 1 minute validity
    simulate: true,         // auto-simulate (default)
    restore: true,          // auto-restore archived entries
    useUpgradedAuth: false  // legacy opt-out: request legacy ADDRESS credential arms (default true)
)

let result = try await client.invokeMethod(
    name: "transfer",
    args: transferArgs,
    methodOptions: methodOptions
)
```

Simulation requests `ADDRESS_V2` credential arms by default (`useUpgradedAuth` is `true` and the key is always sent in the request); pass `false` for legacy `ADDRESS` entries. Legacy `ADDRESS` stays fully valid; emitting V2 arms on a pre-protocol-27 network invalidates the transaction, so opt out there. A supporting RPC records V2 arms; RPC servers without support silently ignore the flag and return legacy `ADDRESS` entries -- detect support by inspecting the credential arm of the returned entries, never by expecting an error.

## Low-Level API: InvokeHostFunctionOperation

For full control over transaction construction, use `InvokeHostFunctionOperation` factory methods directly.

### Upload WASM

```swift
import stellarsdk
import Foundation

let sourceKeyPair = try KeyPair(secretSeed: secretSeed) // secretSeed: your funded account's secret seed ("S...")
let wasmData = try Data(contentsOf: URL(fileURLWithPath: "/path/to/contract.wasm"))
let rpcUrl = "https://soroban-testnet.stellar.org"
let server = SorobanServer(endpoint: rpcUrl)

// 1. Build the upload operation
let uploadOp = try InvokeHostFunctionOperation.forUploadingContractWasm(
    contractCode: wasmData
)

// 2. Load account for sequence number
let accountEnum = await server.getAccount(accountId: sourceKeyPair.accountId)
guard case .success(let account) = accountEnum else {
    throw StellarSDKError.invalidArgument(message: "Account not found")
}

// 3. Build transaction
let transaction = try Transaction(
    sourceAccount: account,
    operations: [uploadOp],
    memo: nil,
    maxOperationFee: 10000
)

// 4. Simulate to get resource requirements
let simRequest = SimulateTransactionRequest(transaction: transaction)
let simEnum = await server.simulateTransaction(simulateTxRequest: simRequest)
guard case .success(let simResponse) = simEnum else {
    throw StellarSDKError.invalidArgument(message: "Simulation failed")
}

// 5. Apply simulation data
if let txData = simResponse.transactionData {
    transaction.setSorobanTransactionData(data: txData)
}
if let minFee = simResponse.minResourceFee {
    transaction.addResourceFee(resourceFee: minFee)
}
if let auth = simResponse.sorobanAuth {
    transaction.setSorobanAuth(auth: auth)
}

// 6. Sign and submit
try transaction.sign(keyPair: sourceKeyPair, network: Network.testnet)
let sendEnum = await server.sendTransaction(transaction: transaction)
guard case .success(let sendResponse) = sendEnum else {
    throw StellarSDKError.invalidArgument(message: "Send failed")
}
print("Transaction ID: \(sendResponse.transactionId)")
```

### Create Contract Instance

```swift
import stellarsdk

let sourceAddress = try SCAddressXDR(accountId: sourceKeyPair.accountId)

// Without constructor
let createOp = try InvokeHostFunctionOperation.forCreatingContract(
    wasmId: wasmHash,
    address: sourceAddress
)

// With constructor (protocol 22+)
let createOpV2 = try InvokeHostFunctionOperation.forCreatingContractWithConstructor(
    wasmId: wasmHash,
    address: sourceAddress,
    constructorArguments: [SCValXDR.symbol("init_arg")]
)
```

### Invoke Contract Function

```swift
import stellarsdk

let invokeOp = try InvokeHostFunctionOperation.forInvokingContract(
    contractId: "CB3FU6M3TOAGRBLN5WDLXL6A7VR5SSRGULMXQQOABNMPS25YRJ4CN5VV", // example contract id — use your deployed contract's id
    functionName: "transfer",
    functionArguments: [
        SCValXDR.address(try SCAddressXDR(accountId: "GA7QYNF7SOWQ3GLR2BGMZEHXAVIRZA4KVWLTJJFC7MGXUA74P7UJVSGZ")), // source
        SCValXDR.address(try SCAddressXDR(accountId: "GCZHXL5HXQX5ABDM26LHYRCQZ5OJFHLOPLZX47WEBP3V2PF5AVFK2A5D")), // destination
        SCValXDR.i128(Int128PartsXDR(hi: 0, lo: 1_000_000_0))
    ]
)
```

### Deploy Stellar Asset Contract (SAC)

```swift
import stellarsdk

let usdcIssuer = try KeyPair(accountId: "GA7QYNF7SOWQ3GLR2BGMZEHXAVIRZA4KVWLTJJFC7MGXUA74P7UJVSGZ") // the asset issuer's account id
let usdcAsset = Asset(type: AssetType.ASSET_TYPE_CREDIT_ALPHANUM4, code: "USDC", issuer: usdcIssuer)!
let sacOp = try InvokeHostFunctionOperation.forDeploySACWithAsset(asset: usdcAsset)
```

## AssembledTransaction for Mid-Level Control

`AssembledTransaction` wraps a transaction-under-construction with simulation, signing, and multi-auth support. Use `SorobanClient.buildInvokeMethodTx` to get one.

```swift
import stellarsdk

// Build without auto-sending
let tx = try await client.buildInvokeMethodTx(
    name: "transfer",
    args: transferArgs,
    methodOptions: MethodOptions(fee: 10000, simulate: false)
)

// Modify before simulation (e.g. adjust the fee)
tx.raw?.setFee(fee: 200_000)

// Simulate manually
try await tx.simulate()

// Inspect simulation data
let simData = try tx.getSimulationData()
print("Return value: \(simData.returnedValue)")

// Sign and send
let response = try await tx.signAndSend()
if response.status == GetTransactionResponse.STATUS_SUCCESS {
    print("Success! Result: \(response.resultValue ?? SCValXDR.void)")
}
```

## Multi-Party Authorization

Soroban supports multiple signers on a single transaction. Use `needsNonInvokerSigningBy` and `signAuthEntries` to coordinate.

### Atomic Swap Example

```swift
import stellarsdk

// swapClient: a SorobanClient for the deployed swap contract
let aliceKeyPair = try KeyPair(secretSeed: aliceSecretSeed) // aliceSecretSeed: Alice's secret seed ("S...")
let bobKeyPair = try KeyPair(secretSeed: bobSecretSeed) // bobSecretSeed: Bob's secret seed ("S...")
let aliceId = aliceKeyPair.accountId
let bobId = bobKeyPair.accountId
let tokenAContractId = "CAQFZ2FHCOA3QLPDVU3XO44TM5TSTLRA7Q47FQADE53UUCJDODNTQIWP" // token A contract
let tokenBContractId = "CBUXFDH3BH5VJKHZMBAR7LEILDY37SKZ7OCAQ7OIWBQANQUBQNPZ6PKG" // token B contract

// Build swap arguments
let args: [SCValXDR] = [
    SCValXDR.address(try SCAddressXDR(accountId: aliceId)),
    SCValXDR.address(try SCAddressXDR(accountId: bobId)),
    SCValXDR.address(try SCAddressXDR(contractId: tokenAContractId)),
    SCValXDR.address(try SCAddressXDR(contractId: tokenBContractId)),
    SCValXDR.i128(Int128PartsXDR(hi: 0, lo: 1000)),   // amountA
    SCValXDR.i128(Int128PartsXDR(hi: 0, lo: 4500)),   // minBForA
    SCValXDR.i128(Int128PartsXDR(hi: 0, lo: 5000)),   // amountB
    SCValXDR.i128(Int128PartsXDR(hi: 0, lo: 950))     // minAForB
]

// Alice builds and simulates (she is the invoker)
let tx = try await swapClient.buildInvokeMethodTx(name: "swap", args: args)

// Check who else needs to sign
let additionalSigners = try tx.needsNonInvokerSigningBy()
// additionalSigners contains Bob's account ID

// Bob signs his auth entries (with his private key)
try await tx.signAuthEntries(signerKeyPair: bobKeyPair)

// Alice signs the transaction envelope and sends
let response = try await tx.signAndSend()
print("Swap status: \(response.status)")
```

### Remote Signing via Callback

When the other signer is on a different server, use the callback pattern:

```swift
import stellarsdk

let bobPublicKeyPair = try KeyPair(accountId: bobId)

try await tx.signAuthEntries(
    signerKeyPair: bobPublicKeyPair,
    authorizeEntryCallback: { entry, network in
        // Encode entry to base64 for transport
        let base64Entry = entry.xdrEncoded!

        // Send to remote server for signing...
        // On the remote server:
        var entryToSign = try SorobanAuthorizationEntryXDR(fromBase64: base64Entry)
        try entryToSign.sign(signer: bobSecretKeyPair, network: network)
        let signedBase64 = entryToSign.xdrEncoded!

        // Return the signed entry
        return try SorobanAuthorizationEntryXDR(fromBase64: signedBase64)
    }
)
```

### Protocol 27 Credential Arms and Delegated Authorization (CAP-71)

`SorobanCredentialsXDR` has four arms: `.sourceAccount`, `.address` (legacy, valid on all protocols), `.addressV2` (the arm simulation requests by default), and `.addressWithDelegates` (both protocol 27). Emitting the newer arms on a pre-protocol-27 network invalidates the transaction; construction is arm-explicit through the enum cases.

Key signatures:

```swift
// extension SorobanCredentialsXDR
var addressCredentials: SorobanAddressCredentialsXDR? { get }  // inner credentials of any address arm; nil for .sourceAccount
func withAddressCredentials(_ c: SorobanAddressCredentialsXDR) throws -> SorobanCredentialsXDR  // arm-preserving write-back

// extension SorobanAuthorizationEntryXDR
func buildPreimage(network: Network) throws -> HashIDPreimageXDR
mutating func sign(signer: KeyPair, network: Network, signatureExpirationLedger: UInt32? = nil, forAddress: String? = nil) throws
static func withDelegates(entry: SorobanAuthorizationEntryXDR, delegates: [SorobanDelegateDescriptor], expirationLedger: UInt32) throws -> SorobanAuthorizationEntryXDR

// Recursive delegate descriptor
public struct SorobanDelegateDescriptor {
    public init(address: String, signature: SCValXDR = .void, nestedDelegates: [SorobanDelegateDescriptor] = [])
}
```

Behavior:

- `sign` handles all three address arms, preserves the arm on write-back, and stamps `signatureExpirationLedger` into the credentials before hashing. `forAddress: nil` signs the top-level node; a non-nil strkey routes the signature into every matching node (top-level or delegate, depth-first) and throws when no node matches.
- `withDelegates` builds a `WITH_DELEGATES` entry from an `ADDRESS`/`ADDRESS_V2` entry: it sorts every delegate array by XDR-encoded address bytes (host requirement -- never sort by strkey), throws on within-array duplicates, copies address and nonce, stamps the expiration, and resets the top-level signature to `.void`.
- One payload per entry: every signer in the tree (top-level and delegates at any depth) signs the same hash, bound to the top-level credential address. Delegates carry no nonce and no expiration.
- A void top-level signature is the legitimate delegates-only pattern; `signAndSend` treats a `WITH_DELEGATES` entry as satisfied when every delegate node carries a signature.
- `needsNonInvokerSigningBy` reports the address of every node with a void signature, including each unsigned delegate node.
- `signAuthEntries(signerKeyPair:)` matches the signer against the top-level address and all delegate nodes and routes signatures via `forAddress` internally.
- Simulation never returns `WITH_DELEGATES` entries; clients assemble the tree with `withDelegates`.

```swift
import stellarsdk

// simResponse = unwrapped simulate result; topLevelKeyPair/delegateKeyPair = your signers;
// latestLedger = unwrapped server.getLatestLedger() (.sequence used for expiration).

// Simulation returned an ADDRESS or ADDRESS_V2 entry
let entry = simResponse.sorobanAuth![0]

var delegated = try SorobanAuthorizationEntryXDR.withDelegates(
    entry: entry,
    delegates: [SorobanDelegateDescriptor(address: delegateKeyPair.accountId)],
    expirationLedger: latestLedger.sequence + 100
)

// Top-level signature (optional: skip for the delegates-only pattern).
// Multiple classical (G) signatures on one node must be added in ascending public-key order.
try delegated.sign(signer: topLevelKeyPair, network: Network.testnet)

// Delegate signature, routed to the matching node
try delegated.sign(signer: delegateKeyPair, network: Network.testnet, forAddress: delegateKeyPair.accountId)

transaction.setSorobanAuth(auth: [delegated])

// Re-simulate in enforcing mode (SimulateTransactionRequest(transaction:, authMode: "enforce"))
// and apply the returned resources before submitting: the recording simulation does not run
// __check_auth, so for a custom (contract) account it omits the footprint its authorization reads.
```

## Error Handling

```swift
import stellarsdk

do {
    let result = try await client.invokeMethod(name: "transfer", args: transferArgs)
} catch let error as SorobanClientError {
    switch error {
    case .methodNotFound(let msg):
        print("Method does not exist: \(msg)")
    case .invokeFailed(let msg):
        print("Invocation failed: \(msg)")
    case .installFailed(let msg):
        print("Install failed: \(msg)")
    case .deployFailed(let msg):
        print("Deploy failed: \(msg)")
    }
} catch let error as AssembledTransactionError {
    switch error {
    case .simulationFailed(let msg):
        print("Simulation error: \(msg)")
    case .restoreNeeded(let msg):
        print("State needs restore: \(msg)")
    case .multipleSignersRequired(let msg):
        print("Multi-sig needed: \(msg)")
    default:
        print("Transaction error: \(error)")
    }
}
```
